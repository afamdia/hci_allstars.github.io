To compile this (assuming you have full MacTeX installation): 

```sh
latexmk -pdf main.tex
```
